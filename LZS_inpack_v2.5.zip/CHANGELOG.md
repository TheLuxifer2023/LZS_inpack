# Changelog - LZS Phyre Engine Pack/Unpack Tool

## Version 2.5 - Complete Font Packing (2025-10-15)

### 🎉 Major Achievement: 100% Font Packing
- ✅ **Template-based packing** - точное воспроизведение размера файла (байт в байт)
- ✅ **100% упаковка шрифтов** - полный цикл Extract → Modify → Pack
- ✅ **Production-ready** - готов к использованию в моддинге

### 🔧 New Features
- **Font Packing**: `-packfont` команда для упаковки BMFont + DDS обратно в .phyre
- **PNG to DDS**: `-todds` команда для конвертации PNG → DDS (L8 format)
- **Template System**: использование оригинального файла как шаблона для точного воспроизведения структуры
- **Trailing Data Copy**: копирование всех данных после текстуры для сохранения размера

### 🐛 Bug Fixes
- **Size Mismatch**: исправлена проблема с размером упакованных файлов (~1.2 MB разница)
- **Structure Integrity**: обеспечена идентичность структуры оригинальному файлу
- **Data Preservation**: сохранение всех метаданных и trailing данных

### 📊 Test Results
```
Original:      5,757,658 bytes
Packed:        5,757,658 bytes
Difference:    0 bytes ✅
Characters:    7447/7447 (100%)
Texture:       2048×2048 L8 (DDS + PNG)
```

### 🔄 Complete Workflow
```
1. EXTRACT  → LZS_inpack.exe -texture original.phyre
2. MODIFY   → Edit PNG in Photoshop/GIMP
3. CONVERT  → LZS_inpack.exe -todds texture.png texture.dds
4. PACK     → LZS_inpack.exe -packfont font.fnt texture.dds modified.phyre
5. USE      → Replace original file in game
```

---

## Version 2.4 - Font Extraction Complete (2025-10-14)

### ✅ Font Extraction Achievements
- **100% Character Extraction**: 7447/7447 символов (включая Unicode)
- **DDS + PNG Export**: автоматическая конвертация текстур
- **BMFont Format**: совместимость с игровыми движками
- **JSON Export**: UTF-8 поддержка для программной обработки

### 🔬 Technical Breakthroughs
- **PBitmapFontCharInfo Structure**: reverse engineered (45 bytes)
- **Template-based Packing**: решение проблемы размера файла
- **L8 Texture Support**: полная поддержка grayscale шрифтов
- **Negative Height Handling**: обработка box-drawing символов

---

## Version 2.0 - Initial Font Support (2025-10-13)

### 🎮 3D Models
- ✅ Unpack `.phyre` → `.smd` + `.mesh.ascii`
- ✅ Pack `.smd` + `.mesh.ascii` → `.phyre`
- ✅ Skeleton animation support
- ✅ UV coordinates and bone weights

### 🔤 Fonts (Basic)
- ✅ Auto-detection of font files
- ✅ Character data extraction
- ✅ Texture extraction (DDS format)
- ✅ BMFont export

---

## Supported Games
- **Killzone** series (PS3/PS4)
- **LittleBigPlanet** series
- **Resistance** series
- **Motorstorm** series
- **Gravity Rush** (PS Vita/PS4)
- **Knack** (PS4)
- **The Order: 1886** (PS4)
- And many other Sony exclusives

---

## Technical Specifications
- **Language**: C# (.NET Framework 4.8.1)
- **Platform**: Windows (x64)
- **Formats**: Phyre, SMD, Mesh.ascii, BMFont, JSON, DDS, PNG
- **Texture Support**: L8 (8-bit Luminance), DXT1/DXT5 (planned)
- **Character Support**: Unicode (Latin, Cyrillic, Greek)
